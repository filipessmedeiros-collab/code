# PhotoCraft floating panel resizing

This contribution spans two repositories. PhotoCraft delegates its floating dock panels to
`craft-ui`; the production fix belongs in that shared library rather than an application overlay.

## Changes

- Four border handles and four corner handles, with horizontal, vertical and diagonal cursors.
- The cursor remains visible while dragging outside the original handle.
- The opposite border stays anchored while resizing from the left or top.
- Panel minimum/maximum sizes and screen bounds constrain resizing.
- Resize regions stay inside the window, leaving adjacent panels alone.
- The existing lower-right keyboard/automation identity is preserved.
- Regression tests cover all eight handles, limits, retained panel content, themes, scales,
  and PhotoCraft workspace restoration.

## Apply and test locally

The patches are already applied in this cloud workspace. Activate its installed Rust toolchain
with `source /workspace/photocraft-panel-resize/env.sh` before running Cargo. On your own machine,
use your normal Rust installation instead.
The cloud's `/workspace/.cargo/config.toml` also supplies the local `craft-ui` override to nested
Cargo commands such as `cargo xtask wasm`; this file is outside both source repositories.

Use sibling checkouts named `craft-libs` and `photocraft`. Each patch applies from its own
repository root. The library patch is based on PhotoCraft's currently pinned craft-ui revision
`5c874d51eeb3de70e735c8ce87a59a7dedd47675`; the application patch is based on
`d95fdf3181c01ad41e95456091a394b105a9afb2`.

```sh
cd craft-libs
git apply /path/to/01-craft-ui-resize.patch
cargo test -p craft-ui --features serde --locked
cargo clippy -p craft-ui --all-targets --features serde --locked -- -D warnings
cargo check -p craft-ui --features serde --target wasm32-unknown-unknown --locked

cd ../photocraft
git apply /path/to/02-photocraft-regression.patch
# Use the local corrected library without changing Cargo.toml or Cargo.lock.
cargo test -p photocraft-ui-egui --lib panel_docking --locked \
  --config 'paths=["../craft-libs/crates/ui"]'
cargo run --release -p photocraft --config 'paths=["../craft-libs/crates/ui"]' -- --new-instance
```

Rust 1.95+ and the Linux window-system development libraries described in PhotoCraft's
`docs/development.md` are prerequisites. Add the wasm target with
`rustup target add wasm32-unknown-unknown`.

## Visual evidence

The `visual/` directory contains offscreen renders of a synthetic docking fixture in light/dark
themes, 640/1000-point windows and 1x/2x scales. These are shared-library fixtures, not screenshots
of the full PhotoCraft application. All eight growth directions are captured; the tests also
resize back to the original dimensions and verify that panel content remains unchanged.

To reproduce them from `craft-libs`:

```sh
CRAFT_UI_DOCK_VISUAL_DIR=/tmp/panel-resize-visual cargo test -p craft-ui --features serde \
  --test docking_workflows floating_borders_resize_content_at_multiple_themes_sizes_and_scales
```

The PhotoCraft regression test separately records all eight regions with
`PHOTOCRAFT_PANEL_RESIZE_VISUAL_DIR=/tmp/photocraft-panel-visual` when running
`floating_brushes_resize_on_all_borders_and_preserve_workspace_geometry`.
The `edge-evidence/` folder contains original PNG frames and GIFs of the real panel growing
from each edge and corner by 96 points. The highlighted demonstrations are
[left edge](edge-evidence/left.gif), [top edge](edge-evidence/top.gif) and
[top-left corner](edge-evidence/top-left.gif), all newly supported regions.

The fixed opposite edge is asserted in the test's layout geometry. Every drag step also
asserts the platform cursor icon. Each frame is painted after applying the layout action so
the captured panel geometry matches the current pointer position.

These animations contain offscreen application frames with mouse input. The optional
`03-test-renderer-cursor.patch` changes only the local test renderer to paint double-headed
arrows from the actual `FullOutput.platform_output.cursor_icon`. This is a software cursor
representation, not native Windows cursor artwork or a Windows recording. The desktop app
continues to use the operating system's native resize cursors.
The [before](photocraft-visual/photocraft-before-resize.png) and
[after](photocraft-visual/photocraft-after-resize.png) compatibility images now show the **left
edge**, replacing the original lower-right example that did not demonstrate the new behavior.

## Upstream integration

1. Submit the library fix and its tests to `storytold/craft-libs`.
2. Once it is merged, update PhotoCraft's `craft-ui` git revision to the actual immutable
   upstream commit, refresh its lockfile, and include the application regression test.
3. Run PhotoCraft's required contribution checks, including the visual snapshot check.

No speculative revision, local absolute path, or dependency lockfile change is included in
these patches. No commit has been pushed and no pull request has been opened.

Validation results and remaining limitations are recorded separately in `VALIDATION.md`.

## Reproduce the cursor-aware test capture (optional)

The product patches remain `01` and `02`. Patch `03` is only for evidence capture, based on
the published `egui_kittest` 0.36.2 source. Copy that Cargo registry package into an external
working folder, apply `03-test-renderer-cursor.patch` there, then include both the corrected
`craft-ui` path and the copied `egui_kittest` path in Cargo's local `paths` override when
running the visual regression. Do not modify the registry's verified package in place.
No dependency declarations or lockfiles in PhotoCraft need changing.
