# Cloud workspace only. Source this file before running the commands in README.md.
export CARGO_HOME=/workspace/.cargo
export RUSTUP_HOME=/workspace/.rustup
export PATH="/workspace/.cargo/bin:$PATH"
export XDG_CACHE_HOME=/workspace/.cache
