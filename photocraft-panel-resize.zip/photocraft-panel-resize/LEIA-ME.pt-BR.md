# Redimensionamento dos painéis do PhotoCraft

A alteração permite redimensionar os painéis flutuantes, como Pincéis, pelas quatro bordas e
pelos quatro cantos. O cursor muda conforme a direção e permanece correto durante o arraste.
O tamanho respeita os limites do painel e da tela, mantendo a borda oposta no lugar.

Os arquivos estão separados para facilitar a contribuição:

- `01-craft-ui-resize.patch`: implementação na biblioteca compartilhada dos painéis e seus testes.
- `02-photocraft-regression.patch`: teste dentro do PhotoCraft, incluindo restauração do espaço de trabalho.
- `photocraft-visual/`: capturas do painel real antes e depois de aumentar seu tamanho.
- `VALIDATION.md`: resultados e limites da validação realizada.
- `README.md`: instruções técnicas em inglês para aplicar e contribuir com as alterações.

As alterações já estão aplicadas neste ambiente, nas pastas `/workspace/craft-libs` e
`/workspace/photocraft`, na branch `fix/floating-panel-border-resize`.

Para ativar o Rust instalado neste ambiente e executar o teste específico:

```sh
source /workspace/photocraft-panel-resize/env.sh
cd /workspace/photocraft
cargo test -p photocraft-ui-egui --lib floating_brushes_resize_on_all_borders --locked
```

A configuração local do Cargo utiliza a biblioteca corrigida. Para publicar a contribuição,
primeiro deve ser incorporada a correção em `storytold/craft-libs`; depois o PhotoCraft deve
atualizar sua referência para o commit efetivamente incorporado. Nenhuma alteração foi enviada
aos repositórios originais.
