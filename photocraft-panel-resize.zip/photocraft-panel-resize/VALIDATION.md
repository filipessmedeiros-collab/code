# Validation

Environment: headless Linux x86_64, Rust 1.99.1. Source pins and local override details are in
README.md. No source dependencies or lockfiles were changed to run the local integration.

| Check | Result |
| --- | --- |
| `craft-ui`: full package tests with `serde` | 84 passed, 0 failed, 0 ignored |
| `craft-ui`: Clippy, all targets, `-D warnings` | Passed |
| `craft-ui`: wasm32 check with `serde` | Passed |
| PhotoCraft: full `photocraft-ui-egui` package tests | 3,198 passed, 0 failed, 13 ignored |
| PhotoCraft: focused docking regression suite | 31 passed, 0 failed |
| PhotoCraft: real Brushes panel visual regression | Passed; before/after PNGs inspected |
| PhotoCraft: architecture (`cargo xtask layers`) | Passed: 31 crates, no violations |
| Both workspaces: `cargo fmt --check` | Passed |
| Both patches: forward application to clean base files | Passed |
| PhotoCraft: full `cargo xtask wasm` | Passed, including `photocraft-codecs --features heif` |
| PhotoCraft: Clippy, all targets, `-D warnings` | Passed |

The 13 ignored tests are marked as such by the project; no tests were disabled or assertions
weakened for this change. The full application package run includes 3,085 passing unit tests and
113 passing integration tests. Its doctest runner reported zero doctests.
The wasm check emitted three dead-code warnings from unchanged `photocraft-engine` code.

The shared-library visual workflow exercises all eight handles in dark/light themes, 640/1000
point windows and 1x/2x scales. It grows and shrinks panels and checks that content and widget
identity are retained. Its 64 growth captures were retained; representative light/dark images
were inspected. The PhotoCraft test separately checks all eight cursor directions and gestures,
valid layout membership, and workspace restoration.

Validation used offscreen rendering and real egui pointer events. An interactive desktop launch,
release installer build, and publication to the original repositories were not performed.
The local path override is required until the shared-library fix is merged and PhotoCraft pins
the resulting upstream commit.

To stay within the cloud machine's disk capacity, debug-only sections were stripped from
generated integration/example executables. Executable code, source files and assertions were
unchanged.

## Evidence follow-up

The first real-panel capture demonstrated the existing lower-right handle. It was insufficient
as evidence of newly supported regions. The follow-up changes only the capture/regression
code; the production fix is unchanged.

The real PhotoCraft test now grows the panel by 96 points from every edge and corner, checks
cursor output on hover and at every drag step, and saves nine frames plus before/after images
per region. Left/top/top-left demos are highlighted. The complete focused docking suite was
rerun: 31 passed, zero failures. Clippy all targets with `-D warnings` was rerun successfully.
The full-package figures above are the original validation run, preceding these test-only
capture changes. No unrelated full suite was repeated for this evidence update.

GIFs are encoded from the original frames using FFmpeg, with endpoint pauses and a shared
palette. They contain no annotations or fabricated resize cursor. Each GIF has 19 frames at
1280×800 and lasts 3.8 seconds.
